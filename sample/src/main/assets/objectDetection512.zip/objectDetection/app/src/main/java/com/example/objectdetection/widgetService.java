package com.example.objectdetection;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioManager;
import android.media.MediaScannerConnection;
import android.media.ToneGenerator;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Layout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;


import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;
import java.util.concurrent.Executor;

public class widgetService extends Service {

    int Layout_Flag;
    View mFloatingView;
    Button btnWindowClose,btnWindowStart;
    private static final String CHANNEL_WHATEVER="channel_whatever";
    private static final int NOTIFY_ID=9906;
    static final String EXTRA_RESULT_CODE="resultCode";
    static final String EXTRA_RESULT_INTENT="resultIntent";
    static final String ACTION_SHOW=
            BuildConfig.APPLICATION_ID+".SHOW";
    static final String ACTION_HIDE=
            BuildConfig.APPLICATION_ID+".HIDE";
    static final int VIRT_DISPLAY_FLAGS=
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY |
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    final private HandlerThread handlerThread=
            new HandlerThread(getClass().getSimpleName(),
                    android.os.Process.THREAD_PRIORITY_BACKGROUND);
    private Handler handler;
    private MediaProjectionManager mgr;
    private WindowManager wmgr;
    private ImageTransmogrifier it;
    private int resultCode;
    private Intent resultData;
    final private ToneGenerator beeper=
            new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
    WindowManager windowManager;

    @Override
    public void onCreate() {
        super.onCreate();

        mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        wmgr=(WindowManager)getSystemService(WINDOW_SERVICE);

        handlerThread.start();



        handler=new Handler(handlerThread.getLooper());




    }



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent.getAction() == null) {
            resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 1337);
            resultData = intent.getParcelableExtra(EXTRA_RESULT_INTENT);
            foregroundify();


        }  else  if (ACTION_SHOW.equals(intent.getAction())) {
            if(mFloatingView.getVisibility()==View.GONE)
            {


                        mFloatingView.setVisibility(View.VISIBLE);


            }

        } else if (ACTION_HIDE.equals(intent.getAction())) {

            if(mFloatingView.getVisibility()==View.VISIBLE)
            {


                        mFloatingView.setVisibility(View.GONE);


            }


        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopCapture();


        super.onDestroy();
            if(mFloatingView!=null){
                windowManager.removeView(mFloatingView);
            }

    }
    WindowManager getWindowManager() {
        return(wmgr);
    }

    Handler getHandler() {
        return(handler);
    }

    void saveBitmapToStorage(final Bitmap bitmap) {

        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);

        byte[] newPng=baos.toByteArray();



        String id= UUID.randomUUID().toString();

        new Thread() {

            @Override
            public void run() {
                File output=new File(getExternalFilesDir(null),
                        "screenshot"+id+".png");

                try {
                    FileOutputStream fos=new FileOutputStream(output);

                    fos.write(newPng);
                    fos.flush();
                    fos.getFD().sync();
                    fos.close();

                    MediaScannerConnection.scanFile(widgetService.this,
                            new String[] {output.getAbsolutePath()},
                            new String[] {"image/png"},
                            null);

                    MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "yourTitle" , "yourDescription");

                }
                catch (Exception e) {
                    Log.e(getClass().getSimpleName(), "Exception writing out screenshot", e);
                }
            }
        }.start();

      //  beeper.startTone(ToneGenerator.TONE_PROP_ACK);
        //stopCapture();
    }

    private void stopCapture() {
        if (projection!=null) {
            projection.stop();
            vdisplay.release();
            projection=null;

        }
    }

    private void getScreenshot() {
        projection=mgr.getMediaProjection(resultCode, resultData);
        it=new ImageTransmogrifier(this);

        MediaProjection.Callback cb=new MediaProjection.Callback() {


            @Override
            public void onStop() {
                vdisplay.release();
            }
        };

        vdisplay=projection.createVirtualDisplay("andshooter",
                it.getWidth(), it.getHeight(),
                getResources().getDisplayMetrics().densityDpi,
                VIRT_DISPLAY_FLAGS, it.getSurface(), null, handler);


        projection.registerCallback(cb, handler);




    }
    private void foregroundify() {
        NotificationManager mgr=
                (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O &&
                mgr.getNotificationChannel(CHANNEL_WHATEVER)==null) {
            mgr.createNotificationChannel(new NotificationChannel(CHANNEL_WHATEVER,
                    "Whatever", NotificationManager.IMPORTANCE_DEFAULT));
        }

        NotificationCompat.Builder b=
                new NotificationCompat.Builder(this, CHANNEL_WHATEVER);

        b.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL);

        b.setContentTitle(getString(R.string.app_name))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setTicker(getString(R.string.app_name));

        b.addAction(R.drawable.ic_stat_show,
                "showWindow",
                buildPendingIntent(ACTION_SHOW));

        b.addAction(R.drawable.ic_stat_hide,
               "HideWindow",
                buildPendingIntent(ACTION_HIDE));

        startForeground(NOTIFY_ID, b.build());
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            Layout_Flag= WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        }
        else {
            Layout_Flag=WindowManager.LayoutParams.TYPE_PHONE;
        }
        mFloatingView= LayoutInflater.from(getApplicationContext()).inflate(R.layout.floatingwindow,null);
        btnWindowClose=mFloatingView.findViewById(R.id.btn_float_Close);
        btnWindowStart=mFloatingView.findViewById(R.id.btn_float_Start);

        btnWindowClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
                stopForeground(true);
                stopCapture();
            }
        });

        btnWindowStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

getScreenshot();

            }

        });

        WindowManager.LayoutParams layoutParams=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Layout_Flag,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        layoutParams.gravity= Gravity.TOP|Gravity.END;
        layoutParams.x=0;
        layoutParams.y=100;


        windowManager=(WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(mFloatingView,layoutParams);


        mFloatingView.setOnTouchListener(new View.OnTouchListener() {

            int initialX,initialY;
            float initialTouchX,initialTouchY;
            long startClickTime;




            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                        initialX=layoutParams.x;
                        initialY=layoutParams.y;
                        initialTouchX=event.getRawX();
                        initialTouchY=event.getRawY();

                        return  true;
                    case MotionEvent.ACTION_UP:
                        layoutParams.x=initialX+(int)(initialTouchX-event.getRawX());
                        layoutParams.y=initialY+(int)(event.getRawY()-initialTouchY);

                        return  true;
                    case MotionEvent.ACTION_MOVE:
                        layoutParams.x=initialX+(int)(initialTouchX-event.getRawX());
                        layoutParams.y=initialY+(int)(event.getRawY()-initialTouchY);
                        windowManager.updateViewLayout(mFloatingView,layoutParams);
                        return  true;

                }
                return false;
            }
        });

    }


    private PendingIntent buildPendingIntent(String action) {
        Intent i=new Intent(this, getClass());

        i.setAction(action);

        return(PendingIntent.getService(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT));
    }


}

