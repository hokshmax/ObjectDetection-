package com.example.objectdetection;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.common.modeldownload.FirebaseModelDownloadConditions;
import com.google.firebase.ml.common.modeldownload.FirebaseModelManager;
import com.google.firebase.ml.custom.FirebaseCustomRemoteModel;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    Button btn_start;
    private static final int REQUEST_SCREENSHOT=59706;
    private MediaProjectionManager mgr;
    FirebaseCustomRemoteModel  remoteModel;

    FirebaseModelDownloadConditions downloadConditions;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestPermission();
        remoteModel =new  FirebaseCustomRemoteModel.Builder("modle512").build();

        downloadConditions = new FirebaseModelDownloadConditions.Builder()
                .requireWifi()
                .build();
        FirebaseModelManager.getInstance().download(remoteModel, downloadConditions).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {



            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });



        getPermission();

        btn_start=findViewById(R.id.btn_start);

        btn_start.setOnClickListener(new View.OnClickListener() {

           @Override
            public void onClick(View v) {
                if(!Settings.canDrawOverlays(MainActivity.this))
                {
                    getPermission();
                }


                else {

                    mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);


                    startActivityForResult(mgr.createScreenCaptureIntent(),
                            REQUEST_SCREENSHOT);



                }

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1)
        {
            if(!Settings.canDrawOverlays(this))
            {
                Toast.makeText(this,"please genrate pemission",Toast.LENGTH_LONG).show();

                return;
            }
        }
        if (requestCode==REQUEST_SCREENSHOT) {
            if (resultCode==RESULT_OK) {
                Intent i=
                        new Intent(this, widgetService.class)
                                .putExtra(widgetService.EXTRA_RESULT_CODE, resultCode)
                                .putExtra(widgetService.EXTRA_RESULT_INTENT, data);

                startService(i);
                finish();

            }
        }


    }
    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[] {
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 47);
        }
    }

    void  getPermission()
    {
      if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M&& !Settings.canDrawOverlays(this))
        {
            Intent  intent=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivityForResult(intent,1);



        }


    }
}